This is my original 80 column text program written back in '89 in Summerland, BC.

I patched up some graphical corruption bugs in 2015, though it's still not a great tool, just a proof of concept. The concept was later refined and perfected in Jeff Brown's TERM80 program.

You must load with Editor/Assembler #3 (LOAD AND RUN): DSK1.MAGICTYPEO

Source for the fixed and original versions are also included.


